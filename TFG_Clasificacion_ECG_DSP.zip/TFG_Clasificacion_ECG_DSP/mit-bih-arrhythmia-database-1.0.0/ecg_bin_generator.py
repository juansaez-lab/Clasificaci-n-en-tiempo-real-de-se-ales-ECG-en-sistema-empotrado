
import wfdb
import numpy as np
import os

def main():
    input_folder = "mit-bih-arrhythmia-database-1.0.0"
    output_file = "ecg_100_q15.bin"
    record_name = "100"  # puedes cambiarlo a "101", "102", etc.

    record_path = os.path.join(input_folder, record_name)
    record = wfdb.rdrecord(record_path)
    signal = record.p_signal[:, 0]

    signal = signal[:10000]  # reduce tamaño para evitar archivos enormes
    signal_norm = signal / np.max(np.abs(signal))
    signal_q15 = np.int16(signal_norm * 32767)
    signal_q15.tofile(output_file)
    print(f"✅ Archivo bin generado: {output_file}")

if __name__ == "__main__":
    main()
