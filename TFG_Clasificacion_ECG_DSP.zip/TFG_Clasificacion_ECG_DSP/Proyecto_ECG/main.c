#include "dsk6416.h"
#include "dsk6416_led.h"
#include <math.h>
#include <string.h>


extern short ecg_signal_207_bloqueo[2000]; // solo declaración global
Uint16 inputsource = 0x0015;
Uint32 fs =250;

#define MIN_DIST 100 // Reducido para señales con arritmia
#define MAX_R 20
#define CVRR_THR   0.12f   /* sdnn/meanRR  -> irregularidad global   */
#define IRR_THR    0.10f   /* rmssd/meanRR -> irregularidad latido a latido */
#define MIN_RR_FA  8 


int r_peaks[MAX_R];
int r_count = 0;
int muestras = 2000;
int p_detectada[MAX_R];           // 1 si se detectó una P antes del QRS, 0 si no
int latido_prematuro[MAX_R - 1];  // uno por cada RR
int hay_patron_bigeminismo = 0;
int tiene_taquicardia = 0;
int tiene_bradicardia = 0;
int tiene_fibrilacion_auricular = 0;
int tiene_extrasistoles = 0;
int tiene_trigeminismo = 0;
int tiene_bigeminismo = 0;
char tipo_arritmia[50];           // Variable para almacenar el nombre del tipo_arritmia
int tiene_bloqueo_rama = 0;
int tiene_RSA = 0;                // Trastorno del ritmo sinusal respiratorio

short ecg_signal_normalizada[2000];
float rr_intervals[MAX_R - 1];
float bpm = 0;
float sdnn = 0;
float rmssd = 0;


float periodo; // Resultados de análisis por latido
int qrs_durations[MAX_R];
int qrs_ms[MAX_R];
volatile short p_amplitudes[MAX_R];
volatile short t_amplitudes[MAX_R];

float calcular_pnn50(float* rr_intervals, int n);

int es_arritmia_rr(float bpm, float sdnn, float rmssd,
                   int* p_detectada, int r_count,
                   float* rr_intervals, int n);

int es_fibrilacion_auricular_rr(float sdnn, float rmssd,
                                int* p_detectada, int r_count,
                                float* rr_intervals, int n);
								
int buscar_maximo(short* signal, int desde, int hasta);
int buscar_minimo(short* signal, int desde, int hasta);
int buscar_valor_maximo(short* signal, int longitud);
int detectar_bigeminismo(float* rr_intervals, int n, float media_rr);
int es_arritmia(float bpm, float sdnn, float rmssd, int* p_detectada, int r_count);
int es_fibrilacion_auricular(float sdnn, float rmssd, int* p_detectada, int r_count);
int detectar_trigeminismo(float* rr_intervals, int n, float media_rr);
int es_extrasistole(int rr_ms, int qrs_ms, int p_detectada);
int es_taquicardia(float bpm);
int es_bradicardia(float bpm);
int es_bloqueo_rama(int* qrs_durations, int r_count);
int es_trastorno_ritmo_respiratorio(float rmssd);
float calculo_sdnn(float* rr_intervals, int n);
float calculo_bpm(float* rr_intervals, int n);
float calcular_rmssd(float* rr_intervals, int cantidad);
float calcular_media_rr(float* rr_intervals, int n);
void diagnostico_basico(float bpm, float sdnn, float rmssd);
void normalizar_senal(short* original, short* ecg_signal_normalizada, int longitud);
void detectar_ondas_p(short* ecg, int* r_peaks, int r_count, int* p_detectada);
void detectar_tipo_arritmia_arritmia(int tiene_taquicardia, int tiene_bradicardia, int tiene_extrasistoles, int tiene_bigeminismo, int tiene_fibrilacion_auricular, char* tipo_arritmia);

void main(void) {
    volatile int i;
    volatile short current;
    volatile short previous = 0;
    volatile int ultima_R = -MIN_DIST;
    float tiempo_total;
    int r_index;
    int q_index;
    int s_index;
    int p_index;
    int t_index;
    int umbral_dinamico;
    int n;
    int latidos_sin_p;
    int tiene_extrasistoles;
    float media_rr;
    float umbral_prematuro;
    int tiene_arritmia;

    normalizar_senal(ecg_signal_207_bloqueo, ecg_signal_normalizada, 2000);

    // Calcular umbral dinámico (80% del valor máximo)
    umbral_dinamico = buscar_valor_maximo(ecg_signal_normalizada, 2000) * 0.8;

    // Paso 1: Detección de picos R
    for (i = 1; i < 2000; i++) {
        current = ecg_signal_normalizada[i];

        if (current > umbral_dinamico && previous <= umbral_dinamico && (i - ultima_R) > MIN_DIST) {
            ultima_R = i;
            if (r_count < MAX_R) {
                r_peaks[r_count++] = i;
                DSK6416_LED_on(1); // LED de detección
            }
        } else {
            DSK6416_LED_off(1);
        }
        previous = current;
    }

    // Calculo los rr_intervals
    for (i = 0; i < r_count - 1; i++) {
        rr_intervals[i] = (r_peaks[i + 1] - r_peaks[i]) * (1000.0f / fs);
    }

    media_rr = calcular_media_rr(rr_intervals, r_count - 1);
    umbral_prematuro = media_rr * 0.8f;

    for (i = 0; i < r_count - 1; i++) {
        if (rr_intervals[i] < umbral_prematuro) {
            latido_prematuro[i] = 1; // latido prematuro detectado
        } else {
            latido_prematuro[i] = 0;
        }
    }

    // Paso 2: Análisis de cada latido
    for (i = 0; i < r_count; i++) {
        r_index = r_peaks[i];
        if (r_index < 80 || r_index > 1920) continue;

        // Detección QRS
        q_index = buscar_minimo(ecg_signal_normalizada, r_index - 1, r_index);
        s_index = buscar_minimo(ecg_signal_normalizada, r_index + 1, r_index + 10);
        qrs_durations[i] = (s_index - q_index);
		

        // Detección P
        p_index = buscar_maximo(ecg_signal_normalizada, r_index - 50, r_index - 10);
        p_amplitudes[i] = ecg_signal_normalizada[p_index];

        // Detección T
        t_index = buscar_maximo(ecg_signal_normalizada, r_index + 40, r_index + 100);
        t_amplitudes[i] = ecg_signal_normalizada[t_index];
    }

    n = r_count - 1;
    bpm = calculo_bpm(rr_intervals, n);
    sdnn = calculo_sdnn(rr_intervals, n);
    rmssd = calcular_rmssd(rr_intervals, n);

    if (detectar_bigeminismo(rr_intervals, r_count - 1, media_rr)) {
        hay_patron_bigeminismo = 1;
    } else {
        hay_patron_bigeminismo = 0;
    }

    detectar_ondas_p(ecg_signal_normalizada, r_peaks, r_count, p_detectada);

    latidos_sin_p = 0;
    for (i = 0; i < r_count; i++) {
        if (!p_detectada[i]) {
            latidos_sin_p++;
        }
    }

    tiene_arritmia = es_arritmia(bpm, sdnn, rmssd, p_detectada, r_count);

    tiene_fibrilacion_auricular = es_fibrilacion_auricular(sdnn, rmssd,
                                p_detectada, r_count);
    tiene_extrasistoles = 0;

    // --- Evaluaciones individuales ---
    tiene_taquicardia = es_taquicardia(bpm);
    tiene_bradicardia = es_bradicardia(bpm);
    tiene_fibrilacion_auricular = es_fibrilacion_auricular(sdnn, rmssd, p_detectada, r_count);
    tiene_trigeminismo = detectar_trigeminismo(rr_intervals, r_count - 1, media_rr);
    tiene_bigeminismo = detectar_bigeminismo(rr_intervals, n, media_rr);
    tiene_bloqueo_rama = es_bloqueo_rama(qrs_durations, r_count);
    tiene_RSA = es_trastorno_ritmo_respiratorio(rmssd);

    // --- Contar extrasístoles ---
 
    for (i = 0; i < r_count - 1; i++) {
        if (es_extrasistole(rr_intervals[i], qrs_durations[i]* (1000 / fs) , p_detectada[i])) {
            tiene_extrasistoles++;
        }
    }

    detectar_tipo_arritmia_arritmia(
        tiene_taquicardia,
        tiene_bradicardia,
        tiene_extrasistoles,
        tiene_bigeminismo,
        tiene_fibrilacion_auricular,
        tipo_arritmia
    );

    while (1);
}

// --- Funciones auxiliares ---
int buscar_maximo(short* signal, int desde, int hasta) {
    int max_index = desde;
    short max_valor = signal[desde];
    int i;

    for (i = desde + 1; i <= hasta; i++) {
        if (signal[i] > max_valor) {
            max_valor = signal[i];
            max_index = i;
        }
    }
    return max_index;
}

int buscar_minimo(short* signal, int desde, int hasta) {
    int min_index = desde;
    short min_valor = signal[desde];
    int i;

    for (i = desde + 1; i <= hasta; i++) {
        if (signal[i] < min_valor) {
            min_valor = signal[i];
            min_index = i;
        }
    }
    return min_index;
}

int buscar_valor_maximo(short* signal, int longitud) {
    short max_valor = signal[0];
    int i;

    for (i = 1; i < longitud; i++) {
        if (signal[i] > max_valor) {
            max_valor = signal[i];
        }
    }
    return max_valor;
}

// rr_intervals en milisegundos
float calculo_sdnn(float* rr_intervals, int n) {
    float suma;
    float media;
    float suma_cuadrados;
    int i;

    if (n <= 1) return 0.0f;

    suma = 0.0f;
    media = 0.0f;
    suma_cuadrados = 0.0f;

    // Calcular media
    for (i = 0; i < n; i++) {
        suma += rr_intervals[i];
    }
    media = suma / n;

    // Calcular suma de las diferencias al cuadrado
    for (i = 0; i < n; i++) {
        float dif = rr_intervals[i] - media;
        suma_cuadrados += dif * dif;
    }

    // Calcular SDNN
    return sqrtf(suma_cuadrados / n); // Si quieres usar n-1 para la varianza muestral: / (n - 1)
}

float calculo_bpm(float* rr_intervals, int n) {
    float suma;
    float media_rr;
    int i;

    if (n == 0) return 0;

    suma = 0.0f;
    for (i = 0; i < n; i++) {
        suma += rr_intervals[i]; // en milisegundos
    }
    media_rr = suma / n; // ms por latido
    return 60000.0f / media_rr; // 60000 ms en 1 minuto
}

float calcular_rmssd(float* rr_intervals, int n) {
    float suma_dif_cuadrados;
    int i;

    if (n < 2) return 0;

    suma_dif_cuadrados = 0.0f;
    for (i = 1; i < n; i++) {
        float diferencia = rr_intervals[i] - rr_intervals[i - 1];
        suma_dif_cuadrados += diferencia * diferencia;
    }
    return sqrtf(suma_dif_cuadrados / (n - 1));
}

float calcular_media_rr(float* rr_intervals, int n) {
    float suma = 0.0f;
    int i;

    for (i = 0; i < n; i++) {
        suma += rr_intervals[i];
    }
    return (n > 0) ? (suma / n) : 0;
}

int detectar_bigeminismo(float* rr_intervals, int n, float media_rr) {
    int i;
    int ciclos_validos = 0;

    for (i = 0; i < n - 1; i += 2) {
        float rr1;
        float rr2;

        rr1 = rr_intervals[i];
        rr2 = rr_intervals[i + 1];

        if (rr1 > media_rr * 1.2 && rr2 < media_rr * 0.8) {
            ciclos_validos++;
        } else {
            break; // Rompe la secuencia
        }
    }
    return (ciclos_validos >= 2); // Al menos 2 ciclos consecutivos
}

void detectar_ondas_p(short* ecg, int* r_peaks, int r_count, int* p_detectada) {
    int i;

    for (i = 0; i < r_count; i++) {
        int r_index;
        int p_index; // ventana típica de onda P
        short p_valor;

        r_index = r_peaks[i];

        // Verificamos que haya espacio suficiente antes del QRS
        if (r_index < 120) {
            p_detectada[i] = 0;
            continue;
        }

        p_index = buscar_maximo(ecg, r_index - 120, r_index - 40); // ventana típica de onda P
        p_valor = ecg[p_index];

        // Consideramos que hay una onda P si su valor es suficientemente prominente
        if (r_index > 300) { // umbral ajustable
            p_detectada[i] = 1;
        } else {
            p_detectada[i] = 0;
        }
    }
}

int es_arritmia(float bpm, float sdnn, float rmssd, int* p_detectada, int r_count) {
    int i;
   

    // Reglas de decisión
    if (bpm < 50 || bpm > 100) return 1;       // FC anormal
    if (sdnn > 50) return 1;                   // Variabilidad excesiva
    if (rmssd < 30 && rmssd != 0) return 1;    // Variabilidad muy baja
               // Múltiples latidos sin onda P

    return 0; // Ritmo normal
}

int es_fibrilacion_auricular(float sdnn, float rmssd, int* p_detectada, int r_count) {
    int i;
    int sin_p = 0;

    for (i = 0; i < r_count; i++) {
        if (!p_detectada[i]) sin_p++;
    }

    // Casos válidos de FA:
    // 1. Alta variabilidad y latidos sin onda P
    // 2. Variabilidad extrema, aunque haya onda P en todos
    if ((sdnn > 100.0f && rmssd > 100.0f && sin_p >= 3) || (sdnn > 120.0f && rmssd > 120.0f)) {
        return 1;
    }
    return 0;
}

int es_taquicardia(float bpm) {
    return bpm > 100.0f;
}

int es_bradicardia(float bpm) {
    return bpm < 60.0f;
}

int es_extrasistole(int rr_ms, int qrs_ms, int p_detectada) {
    return (rr_ms < 600 && (qrs_ms  > 120 ||  p_detectada == 0)); // umbrales típicos
}

int detectar_trigeminismo(float* rr_intervals, int n, float media_rr) {
    int i, ciclos_validos = 0;

    for (i = 0; i < n - 2; i += 3) {
        float rr1 = rr_intervals[i];
        float rr2 = rr_intervals[i + 1];
        float rr3 = rr_intervals[i + 2];

        if (rr1 > media_rr * 1.2f && rr2 < media_rr * 0.8f && rr3 > media_rr * 1.2f) {
            ciclos_validos++;
        } else {
            break;
        }
    }
    return (ciclos_validos >= 1); // al menos un patrón detectado
}

void detectar_tipo_arritmia_arritmia(
    int tiene_taquicardia,
    int tiene_bradicardia,
    int tiene_extrasistoles,
    int tiene_bigeminismo,
    int tiene_fibrilacion_auricular,
    char* tipo_arritmia
) {
    if (tiene_fibrilacion_auricular) {
        strcpy(tipo_arritmia, "Fibrilación auricular");
    } else if (tiene_bigeminismo) {
        strcpy(tipo_arritmia, "Bigeminismo");
    } else if (tiene_extrasistoles) {
        strcpy(tipo_arritmia, "Extrasístole");
    } else if (tiene_taquicardia) {
        strcpy(tipo_arritmia, "Taquicardia sinusal");
    } else if (tiene_bradicardia) {
        strcpy(tipo_arritmia, "Bradicardia sinusal");
    } else {
        strcpy(tipo_arritmia, "Ritmo normal");
    }
}

int es_bloqueo_rama(int* qrs_durations, int r_count) {
    int i;
    int bloqueos = 0;

    for (i = 0; i < r_count; i++) {
        if (qrs_durations[i]*(1000/fs) > 30) { // 30 muestras ≈ 120 ms a 250 Hz
            bloqueos++;
        }
    }
    // Si más del 50% tienen QRS ancho, puede indicar bloqueo de rama
    return (bloqueos > r_count / 2);
}

int es_trastorno_ritmo_respiratorio(float rmssd) {
    return rmssd > 80.0f; // Umbral aproximado, puedes ajustarlo según pruebas
}



void normalizar_senal(short* original, short* ecg_signal_normalizada, int longitud) {
    int i;
    short min = original[0];
    short max = original[0];

    // Buscar mínimo y máximo
    for (i = 1; i < longitud; i++) {
        if (original[i] < min) min = original[i];
        if (original[i] > max) max = original[i];
    }

    // Evitar división por cero
    if (max == min) {
        for (i = 0; i < longitud; i++) {
            ecg_signal_normalizada[i] = 0;
        }
        return;
    }

    // Normalizar a [0, 1000]
    for (i = 0; i < longitud; i++) {
        ecg_signal_normalizada[i] = (short)(((original[i] - min) * 1000) / (max - min));
    }
}
