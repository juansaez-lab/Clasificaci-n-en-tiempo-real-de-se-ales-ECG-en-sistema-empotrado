#include "DSK6416_AIC23.h"           

Uint32 fs=DSK6416_AIC23_FREQ_8KHZ;   
#define DSK6416_AIC23_INPUT_MIC 0x0015
#define DSK6416_AIC23_INPUT_LINE 0x0011

Uint16 inputsource=DSK6416_AIC23_INPUT_MIC; 

short output_sample_value = 0; 

interrupt void c_int11()
{
  output_sample(output_sample_value); // Env�a el valor de muestra de salida
  output_sample_value += 2000; // Incrementa el valor de muestra en 2000

  // Si el valor de muestra alcanza 30000, resetea a -30000
  if (output_sample_value >= 30000)
    output_sample_value = -30000;

  return;
}

void main()
{
  comm_intr(); // Configura las interrupciones

  while(1); // Bucle infinito
}
